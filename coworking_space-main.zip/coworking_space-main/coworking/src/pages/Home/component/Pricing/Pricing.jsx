import "bootstrap/dist/css/bootstrap.css";
import "./Pricing.css";
function Pricing() {
  return (
    <section id="pricing" class="pricing">
        <div class="container">

          <div class="section-title" data-aos="fade-down">
            <span>Pricing</span>
            <h2>Pricing</h2>
            <p>text text text text text text text text text text text text</p>
          </div>

          <div class="row no-gutters">

            <div class="col-lg-4 box" data-aos="zoom-in" data-aos-delay="200">
              <h3>text</h3>
              <h4>$99<span>Per day</span></h4>
              <ul>
                <li><i class="bx bx-check"></i> text text text text text text text text </li>
                <li><i class="bx bx-check"></i> text text text text text text text text </li>
                <li><i class="bx bx-check"></i> text text text text text text text text </li>
                <li class="na"><i class="bx bx-x"></i> <span>text text text text text text text text </span></li>
                <li class="na"><i class="bx bx-x"></i> <span>text text text text text text text text </span></li>
              </ul>
            </div>

            <div class="col-lg-4 box featured" data-aos="zoom-in" data-aos-delay="100">
              <h3>text</h3>
              <h4>$99<span>Per month</span></h4>
              <ul>
                <li><i class="bx bx-check"></i> text text text text text text text text </li>
                <li><i class="bx bx-check"></i> text text text text text text text text </li>
                <li><i class="bx bx-check"></i> text text text text text text text text </li>
                <li><i class="bx bx-check"></i> text text text text text text text text </li>
                <li><i class="bx bx-check"></i> text text text text text text text text </li>
              </ul>
            </div>

            <div class="col-lg-4 box" data-aos="zoom-in" data-aos-delay="200">
              <h3>text</h3>
              <h4>$99<span>Per year</span></h4>
              <ul>
                <li><i class="bx bx-check"></i> text text text text text text text text </li>
                <li><i class="bx bx-check"></i> text text text text text text text text </li>
                <li><i class="bx bx-check"></i> text text text text text text text text </li>
                <li><i class="bx bx-check"></i> text text text text text text text text </li>
                <li><i class="bx bx-check"></i> text text text text text text text text </li>
              </ul>
            </div>

          </div>

        </div>
      </section>
  );
}

export default Pricing;
