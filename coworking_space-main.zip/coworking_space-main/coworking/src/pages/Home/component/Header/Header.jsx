import "bootstrap/dist/css/bootstrap.css";
import { useRef } from "react";
import { FaBars, FaTimes } from "react-icons/fa";
import logo from "./../../../../assets/Logo.png";
import "./Header.css";

function Header() {
  const navRef = useRef();
  const showNavbar = () => {
    navRef.current.classList.toggle("responsive_nav");
  };
  return (
    <div>
      <header id="header" className="fixed-top header-transparent">
        <div className="container d-flex align-items-center justify-content-between position-relative"></div>
      </header>
      <section id="hero">
        <div className="Navbar_responsive">
          <img src={logo} />
          <nav ref={navRef}>
            <a href="#about" >About us</a>
            <a href="#features">our espace</a>
            <a href="#cta">service de domiciliation</a>
            <a href="#pricing">Pricing</a>
            <a href="#contact">contact us</a>
            <button className="nav-btn nav-close-btn" onClick={showNavbar}>
              <FaTimes />
            </button>
          </nav>
          <button className="nav-btn" onClick={showNavbar}>
            <FaBars />
          </button>
        </div>
        <div className="hero-container" data-aos="fade-up">
          <h1>
            Welcome to <span className="C">C</span>
            <span className="AND">&</span>
            <span className="D">D</span>
          </h1>
          <h2>text text text text text text text text text text</h2>
          <a href="#about" className="btn btn-outline-light">
            Découvrir notre espace
          </a>
        </div>
      </section>
    </div>
  );
}

export default Header;
