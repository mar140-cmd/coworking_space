import "bootstrap/dist/css/bootstrap.css";
import "./Espace.css";
import espace1 from "./../../../../assets/slide/slide-2.jpg"
import espace2 from "./../../../../assets/slide/slide-2.jpg"
import espace3 from "./../../../../assets/slide/slide-2.jpg"
function Espace() {
    return ( 
        <section id="features" class="features">
        <div class="container">
        <div className="section-title" data-aos="fade-down">
            <span>our espace</span>
            <h2>our espace</h2>
            <p>text text text text text text text text text text text text</p>
          </div>
          <div class="row">
            <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
              <div class="card" data-aos="fade-up">
                <img src={espace1} class="card-img-top" alt="..."/>
                <div class="card-body">
                  
                  <h5 class="card-title"><a href="">text text</a></h5>
                  <p class="card-text">text text text text text text text text text text text text text text text text text text text text text text text text text text text text text text text text </p>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-md-6 mt-5 mt-md-0 d-flex align-items-stretch">
              <div class="card" data-aos="fade-up" data-aos-delay="150">
                <img src={espace1} class="card-img-top" alt="..."/>
                <div class="card-body">
                 
                  <h5 class="card-title"><a href="">text text</a></h5>
                  <p class="card-text">text text text text text text text text text text text text text text text text text text text text text text text text text text text text text text text text</p>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-md-6 mt-5 mt-lg-0 d-flex align-items-stretch">
              <div class="card" data-aos="fade-up" data-aos-delay="300">
                <img src={espace1} class="card-img-top" alt="..."/>
                <div class="card-body">
                  <h5 class="card-title"><a href="">text text</a></h5>
                  <p class="card-text">text text text text text text text text text text text text text text text text text text text text text text text text text text text text text text text text </p>
                </div>
              </div>
            </div>
          </div>

        </div>
      </section> );
}

export default Espace;