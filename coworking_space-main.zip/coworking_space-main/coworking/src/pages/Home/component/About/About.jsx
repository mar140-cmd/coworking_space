import "bootstrap/dist/css/bootstrap.css";
import "./About.css";
function About() {
  return (
    <section id="about" className="about">
      <div className="container">
        <div className="row">
          <div className="section-title" data-aos="fade-down">
            <span>about us</span>
            <h2>about us</h2>
            <p>text text text text text text text text text text text text</p>
          </div>
          <div
            data-aos="fade-right"
            className="image col-xl-5 d-flex align-items-stretch justify-content-center justify-content-lg-start style"
          ></div>
          <div className="col-xl-7 pt-4 pt-lg-0 d-flex align-items-stretch">
            <div
              className="content d-flex flex-column justify-content-center"
              data-aos="fade-left"
            >
              <h3>text text text text text text text text </h3>
              <p>
                text text text text text text text text text text text text text
                text text text text text text text text text text text text text
                text text text text text text
              </p>
              <div className="row">
                <div
                  className="col-md-6 icon-box"
                  data-aos="zoom-in"
                  data-aos-delay="100"
                >
                  <i >
                  <lord-icon
                      src="https://cdn.lordicon.com/vpcmkqzt.json"
                      trigger="hover"
                      colors="primary:#DBA385"
                    ></lord-icon>
                  </i>
                  <h4>service 1</h4>
                  <p>
                    text text text text text text text text text text text text
                    text text text text
                  </p>
                </div>
                <div
                  className="col-md-6 icon-box"
                  data-aos="zoom-in"
                  data-aos-delay="200"
                >
                  <i >
                  <lord-icon
                        src="https://cdn.lordicon.com/juasohjt.json"
                      trigger="hover"
                      colors="primary:#DBA385"
                     
                    ></lord-icon>
                  </i>
                  <h4>service 2</h4>
                  <p>
                    text text text text text text text text text text text text
                    text text text text
                  </p>
                </div>
                <div
                  className="col-md-6 icon-box"
                  data-aos="zoom-in"
                  data-aos-delay="300"
                >
                  <i >
                    <lord-icon
                      src="https://cdn.lordicon.com/iiixgoqp.json"
                      trigger="hover"
                      colors="primary:#DBA385"
                      
                    ></lord-icon>
                  </i>
                  <h4>service 3</h4>
                  <p>
                    text text text text text text text text text text text text
                    text text text text
                  </p>
                </div>
                <div
                  className="col-md-6 icon-box"
                  data-aos="zoom-in"
                  data-aos-delay="400"
                >
                  <i >
                  <lord-icon
                      src="https://cdn.lordicon.com/ycwlopoz.json"
                      trigger="hover"
                      colors="primary:#DBA385"
                      
                    ></lord-icon>
                  </i>
                  <h4>service 4</h4>
                  <p>
                    text text text text text text text text text text text text
                    text text text text
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default About;
