import "bootstrap/dist/css/bootstrap.css";
import '@fortawesome/fontawesome-svg-core/styles.css'; 
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faChevronRight } from '@fortawesome/free-solid-svg-icons';
import "./Footer.css";
function Footer() {
  return (
    <footer id="footer">
      <div class="footer-top">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-xl-10">
              <div class="row">
                <div class="col-lg-3 col-md-6 footer-links">
                  <h4>Useful Links</h4>
                  <ul>
                    <li>
                      <FontAwesomeIcon icon={faChevronRight} className="FontAwesomeIcon" />
                      <a href="#about">About us</a>
                    </li>
                    <li>
                      <FontAwesomeIcon icon={faChevronRight} className="FontAwesomeIcon" />
                      <a href="#features">our espace</a>
                    </li>
                    <li>
                      <FontAwesomeIcon icon={faChevronRight} className="FontAwesomeIcon" />
                      <a href="#cta">service de domiciliation</a>
                    </li>
                    <li>
                    <FontAwesomeIcon icon={faChevronRight} className="FontAwesomeIcon" />
                      <a href="#pricing">Pricing</a>
                    </li>
                    <li>
                      <FontAwesomeIcon icon={faChevronRight} className="FontAwesomeIcon" />
                      <a href="#contact">contact us</a>
                    </li>


                  </ul>
                </div>

                <div class="col-lg-3 col-md-6 footer-links">
                  <h4>Our Services</h4>
                  <ul>
                    <li>
                      <FontAwesomeIcon icon={faChevronRight} className="FontAwesomeIcon" />
                      <a href="#about">service 1</a>
                    </li>
                    <li>
                      <FontAwesomeIcon icon={faChevronRight} className="FontAwesomeIcon" />
                      <a href="#about">service 2</a>
                    </li>
                    <li>
                      <FontAwesomeIcon icon={faChevronRight} className="FontAwesomeIcon" />
                      <a href="#about">service 3</a>
                    </li>
                    <li>
                      <FontAwesomeIcon icon={faChevronRight} className="FontAwesomeIcon" />
                      <a href="#about">service 4</a>
                    </li>
                  </ul>
                </div>

                <div class="col-lg-3 col-md-6 footer-contact">
                  <h4>Contact Us</h4>
                  <a>
                    Address Address <br />
                    Address Address
                    <br />
                    Address Address <br />
                    <br />
                    <strong>Phone:</strong> +000 00 000 000
                    <br />
                    <strong>Email:</strong> contact@example.com
                    <br />
                  </a>
                </div>

                <div class="col-lg-3 col-md-6 footer-info">
                  <h3>About C&D</h3>
                  <p>
                    text text text text text text text text text text text text
                    text text text text text text text text text text text text
                    text text text text text text text text
                  </p>
                  <div class="social-links mt-3">
                    <a href="#" class="twitter">
                      <i class="bx bxl-twitter"></i>
                    </a>
                    <a href="#" class="facebook">
                      <i class="bx bxl-facebook"></i>
                    </a>
                    <a href="#" class="instagram">
                      <i class="bx bxl-instagram"></i>
                    </a>
                    <a href="#" class="google-plus">
                      <i class="bx bxl-skype"></i>
                    </a>
                    <a href="#" class="linkedin">
                      <i class="bx bxl-linkedin"></i>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="container">
        <div class="copyright">
          &copy; Copyright{" "}
          <strong>
            <span>C&D</span>
          </strong>
          . All Rights Reserved
        </div>
        <div class="credits">
          Designed by{" "}
          <a href="https://github.com/ayarinesrine" class="Nesrine">
            Nesrine Ayari
          </a>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
