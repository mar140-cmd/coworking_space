import "bootstrap/dist/css/bootstrap.css";
import "./Domiciliation.css";
function Domiciliation() {
    return (  <div>
        <section id="cta" class="cta">
          <div class="container">
            <div class="text-center">
             <h3>SERVICE DE DOMICILIATION</h3>
             
             <i>
                  <lord-icon
                  
                  src="https://cdn.lordicon.com/osuxyevn.json"
                        trigger="hover"
                        colors="primary:white"
                        
                        style={{width:100 +"px",height:100+"px"}}
                  ></lord-icon>
                </i>
                <h5> text text text text text text text text text </h5>
                <h5> text text text text </h5>
            </div>
          </div>
        </section>
      </div> );
}

export default Domiciliation;