import Header from "./component/Header/Header";
import About from "./component/About/About";
import Pricing from "./component/Pricing/Pricing";
import Contact from "./component/Contact/Contact";
import Footer from "./component/Footer/Footer";
import Domiciliation from "./component/Domiciliation/Domiciliation";
import Espace from "./component/Espace/Espace";
function Home() {
  return (
    <div>
      <Header />
      <About />
      <Espace />
      <Domiciliation />
      <Pricing />
      <Contact />
      <Footer />
    </div>
  );
}

export default Home;
